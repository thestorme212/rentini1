<tr>

    <td>



        <div class="entry input-group  social-icon-group ">

            <input name="attributes[value][]" type="text"  value="{{$item ?? ''}}" class="form-control"
                   placeholder="{{__('admin.Value')}}">
            <span class="input-group-btn">
                                                       <button class="btn btn-danger btn-delete" type="button">
                                <span class="glyphicon glyphicon-minus"></span>
                            </button>
	                                                       </span>

        </div>
    </td>
</tr>
